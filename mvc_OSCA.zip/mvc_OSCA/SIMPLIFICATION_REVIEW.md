# MVC Simplification Review

## Goal

This cleanup keeps the current MVC application behavior while removing code and files that are not used by the application or that add complexity without providing a current feature.

## Removed safely

### 1. `App/Core/auth_helper.php`
Removed because it was only a compatibility wrapper around `helpers.php` and had no references anywhere in the application.

### 2. `User::emailExists()`
Removed because no controller, view, router, or other model calls it. The registration flow already checks `findByEmail()` directly.

### 3. `flash_forget()` helper
Removed because it had no callers. The existing code uses `flash_get()` when a message should be read and cleared.

### 4. `extraCss` / `extraJs` extension plumbing
Removed from the shared authenticated layout and `DashboardController`. Those arrays were only initialized as empty arrays and were never populated by any page.

### 5. Unused DashboardController parameter
`DashboardController::show(string $page = 'home')` was simplified to `show()`. The argument was never used.

### 6. Duplicate user database lookup in `public/index.php`
The router no longer creates a `User` model and queries the current user just to decide where to route. Controllers already call `requireUser()` and perform the relevant role checks. The router still preserves the existing session-role-based default routing behavior for admin/teacher pages.

### 7. Unused `coordinator_students` route alias
No link or form in the application uses this route. The actual coordinator home page is already `home`, so the alias was removed from the router.

### 8. Unused Bootstrap distribution files
The application directly references only:

- `bootstrap.min.css`
- `bootstrap.bundle.min.js`

The other Bootstrap source, RTL, grid, reboot, utilities, ESM, and source-map files were not referenced by the application and were removed. The bundled Bootstrap CSS/JS functionality remains available.

## Intentionally kept

### `StudentRoster` table creation code
This looks more complicated than a typical simple MVC model, but it is currently necessary because `users.sql` creates the `users` table but does not create the coordinator tables used by the application:

- `coordinator_students`
- `coordinator_sports`
- `coordinator_schedules`

The runtime table creation therefore prevents the coordinator features from failing on a database that has not yet created those tables.

### `ensureColumn()`
Also kept because it supports older `coordinator_students` tables that may be missing fields added later to the system. Removing it without a database migration would risk breaking existing installations.

### PHPMailer files
Kept as a third-party dependency. Although PHPMailer contains many classes/features the application does not directly use, pruning the vendor library manually would make updates and troubleshooting harder. The application only loads the files it needs at runtime.

### Authentication and OTP logic
Kept as-is. Login, registration, email OTP verification, forgot-password OTP, password change OTP, and Coordinator approval contain separate business rules. Combining these flows further would make the code shorter but harder to explain and easier to break.

### Existing MVC structure
Controllers, models, views, configuration, and shared helpers remain separated. No framework, autoloader, namespace layer, repository pattern, service layer, dependency injection container, or other advanced architecture was introduced.

## Database fields worth reviewing later

The current `users.sql` contains fields that have no references in the PHP application at present:

- `teacher_otp_requested_at`
- `pending_expires_at`
- `profile_image`

These were intentionally **not** removed from the schema in this cleanup because changing the database structure is more invasive than removing unused PHP code. They can be removed safely only as part of a deliberate database migration after confirming that no other project version, report, or future feature depends on them.

## Existing behavior intentionally preserved

- Existing public entry pages remain in `public/`.
- Existing route names remain unchanged except the unused `coordinator_students` alias.
- Existing controller class names remain unchanged.
- Existing model class names remain unchanged.
- Existing view paths remain unchanged from the prior organized structure.
- Session-based authentication, role checks, flash messages, OTP handling, password hashing, reCAPTCHA, Coordinator approval, student management, scheduling, reports, and printing remain intact.

## Validation performed

- PHP syntax check: all application PHP files passed `php -l`.
- Literal `__DIR__` include targets: no missing targets found.
- `renderApp()` / `renderAuth()` view targets: all resolve to existing view files.
- Public entry-point controller includes: all resolve to existing controller files.
- Removed symbols: no references remain to `auth_helper.php`, `flash_forget()`, `emailExists()`, `$extraCss`, or `$extraJs`.

A live database test was not performed in this environment because the available CLI PHP installation does not have the `mysqli` extension. This is an environment limitation, not a reported application failure.

## Security note

`App/Config/app.php` currently contains real-looking reCAPTCHA and SMTP credential values. These should be rotated and moved out of source code before the project is published or committed to a shared repository.
