<?php
/**
 * Front controller for authenticated pages.
 * Routes requests to the correct controller based on the url parameter.
 */
session_start();

require_once "../App/Controllers/dashboard/DashboardController.php";
require_once "../App/Controllers/coordinator/CoordinatorController.php";
require_once "../App/Controllers/profile/ProfileController.php";
require_once "../App/Controllers/password/PasswordController.php";
require_once "../App/Controllers/admin/AdminController.php";
$page = $_GET['url'] ?? 'home';
$role = $_SESSION['role'] ?? '';

// Keep the original role-based default routing, while controllers enforce access too.
if ($role === 'admin') {
    $allowedPages = ['admin_dashboard', 'admin_edit_user'];
    if (!in_array($page, $allowedPages, true)) {
        $page = 'admin_dashboard';
    }
} elseif ($role === 'teacher') {
    $allowedPages = ['home', 'athletes', 'dance', 'sports', 'schedule', 'reports', 'profile', 'edit_profile', 'change_password', 'verify_change_password_otp', 'set_new_password'];
    if (!in_array($page, $allowedPages, true)) {
        $page = 'home';
    }
} elseif (in_array($page, ['athletes', 'dance', 'sports', 'schedule', 'reports'], true) || str_starts_with($page, 'admin_')) {
    $page = 'home';
}

switch ($page) {
    case 'athletes':
    case 'dance':
    case 'sports':
    case 'schedule':
    case 'reports':
        (new CoordinatorController())->show($page);
        break;

    case 'admin_dashboard':
        (new AdminController())->dashboard();
        break;

    case 'admin_edit_user':
        (new AdminController())->editUser();
        break;

    case 'profile':
        (new ProfileController())->show();
        break;

    case 'edit_profile':
        (new ProfileController())->edit();
        break;

    case 'change_password':
        (new PasswordController())->changePassword();
        break;

    case 'verify_change_password_otp':
        (new PasswordController())->verifyChangePasswordOtp();
        break;

    case 'set_new_password':
        (new PasswordController())->setNewPassword();
        break;

    case 'home':
    default:
        // Controllers handle authentication and role checks.
        if (($_SESSION['role'] ?? '') === 'teacher') {
            (new CoordinatorController())->show('home');
        } else {
            (new DashboardController())->show();
        }
        break;
}
