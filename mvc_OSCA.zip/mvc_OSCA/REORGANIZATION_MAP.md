# MVC Reorganization Map

This copy reorganizes the existing PHP MVC project without changing its public URLs, route keys, class names, database schema, or application behavior.

## Controllers
- `App/Controllers/admin/AdminController.php`
- `App/Controllers/auth/AuthController.php`
- `App/Controllers/coordinator/CoordinatorController.php`
- `App/Controllers/dashboard/DashboardController.php`
- `App/Controllers/password/PasswordController.php`
- `App/Controllers/profile/ProfileController.php`

## Models
- `App/Models/account/User.php` — shared account model used by authentication, profile, password, dashboard, and admin flows.
- `App/Models/coordinator/StudentRoster.php` — coordinator roster/sports/schedule data, also read by the admin dashboard.

## Views
- `App/Views/admin/dashboard/index.php`
- `App/Views/admin/users/edit_user.php`
- `App/Views/auth/*`
- `App/Views/coordinator/*`
- `App/Views/dashboard/*`
- `App/Views/password/*`
- `App/Views/profile/*`
- `App/Views/layout/*` — shared layouts/partials

## Intentionally unchanged
- Public entry-point filenames and URLs such as `login.php`, `register.php`, `verify_otp.php`, etc.
- Route keys such as `admin_dashboard`, `admin_edit_user`, `profile`, `edit_profile`, and `home`.
- Class names and namespaces (the project currently uses no PHP namespaces).
- Database/config files and the `public/` asset structure.

## Path updates made
Nested controllers now use `../../Core` / `../../Models` / `../../Views` paths.
Models moved one level deeper now use `../../Core` or `../../Config` paths.
`public/*.php` entry points now require controllers from their feature folders.
The base `App/Core/Controller.php` now loads `Models/account/User.php`.
