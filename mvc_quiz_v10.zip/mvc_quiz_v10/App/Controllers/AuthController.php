<?php
/**
 * Handles guest-facing authentication pages:
 * login, register, OTP verification, setup account and logout.
 */
require_once __DIR__ . '/../Core/Controller.php';

class AuthController extends Controller {
    /**
     * Render and process the login form.
     */
    public function login(): void {
        $this->requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            $captcha = verify_recaptcha_token($_POST['g-recaptcha-response'] ?? null);
            if (!$captcha['ok']) {
                flash_set('auth_error', $captcha['message']);
                redirect('login.php');
            }

            $user = $this->userModel->findByEmail($email);

            if (!$user || !password_verify($password, $user['password'])) {
                flash_set('auth_error', 'Invalid login credentials.');
                redirect('login.php');
            }

            if (($user['status'] ?? '') !== 'verified') {
                $_SESSION['pending_email'] = $user['email'];
                flash_set('auth_success', 'Your account is pending. Enter the OTP we sent to your email.');
                redirect('verify_otp.php');
            }

            if (empty($user['profile_completed'])) {
                $_SESSION['setup_email'] = $user['email'];
                redirect('setup_account.php');
            }

            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            if (($user['role'] ?? '') === 'admin') {
                redirect('index.php?url=admin_dashboard');
            }

            redirect('index.php?url=home');
        }

        $this->renderAuth('auth/login', [
            'pageTitle' => 'Login',
            'formTitle' => 'Sign in',
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success'),
            'showRecaptcha' => recaptcha_enabled()
        ]);
    }

    /**
     * Render and process the email/password registration form.
     */
    public function register(): void {
        $this->requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';

            if (empty($email) || empty($password) || empty($confirm)) {
                flash_set('auth_error', 'Please fill in all required fields.');
                redirect('login.php');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                flash_set('auth_error', 'Please enter a valid email address.');
                redirect('register.php');
            }

            if ($password !== $confirm) {
                flash_set('auth_error', 'Passwords do not match.');
                redirect('register.php');
            }

            $captcha = verify_recaptcha_token($_POST['g-recaptcha-response'] ?? null);
            if (!$captcha['ok']) {
                flash_set('auth_error', $captcha['message']);
                redirect('register.php');
            }

            $existingUser = $this->userModel->findByEmail($email);
            if ($existingUser) {
                if (($existingUser['status'] ?? '') === 'pending') {
                    $otp = random_otp();
                    $otpExpiry = otp_expiry_time();
                    $this->userModel->updateOtp($email, $otp, $otpExpiry);
                    send_otp_email($email, $otp, 'Your OTP Code', 'Your verification code is');
                    $_SESSION['pending_email'] = $email;
                    flash_set('auth_success', 'This account is still pending. We sent a fresh OTP to your email.');
                    redirect('verify_otp.php');
                }

                flash_set('auth_error', 'Email already exists.');
                redirect('register.php');
            }

            $otp = random_otp();
            $otpExpiry = otp_expiry_time();
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);

            if (!$this->userModel->createPendingAccount($email, $passwordHash, $otp, $otpExpiry)) {
                flash_set('auth_error', 'Registration failed. Please try again.');
                redirect('register.php');
            }

            $mailResult = send_otp_email($email, $otp);

            if (!$mailResult['ok']) {
                flash_set('auth_error', 'Account created, but OTP email could not be sent.');
            } else {
                flash_set('auth_success', 'OTP sent to your email.');
            }

            $_SESSION['pending_email'] = $email;
            redirect('verify_otp.php');
        }

        $this->renderAuth('auth/register', [
            'pageTitle' => 'Register',
            'heroTag' => 'Create Account',
            'heroTitle' => 'Create your account',
            'heroDescription' => 'Create your account first, verify your email, then finish your student profile.',
            'formTitle' => 'Create account',
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success'),
            'showRecaptcha' => recaptcha_enabled()
        ]);
    }

    /**
     * Resend the registration OTP to the pending email address.
     */
    public function resendOtp(): void {
        $email = $_SESSION['pending_email'] ?? '';
        if ($email === '') {
            redirect('login.php');
        }

        $user = $this->userModel->findByEmail($email);
        if (!$user || ($user['status'] ?? '') !== 'pending') {
            flash_set('auth_error', 'No pending account found for OTP resend.');
            redirect('login.php');
        }

        $otp = random_otp();
        $otpExpiry = otp_expiry_time();
        $this->userModel->updateOtp($email, $otp, $otpExpiry);
        $mailResult = send_otp_email($email, $otp, 'Your New OTP Code', 'Your new verification code is');

        if ($mailResult['ok']) {
            flash_set('auth_success', 'New OTP has been sent.');
        } else {
            flash_set('auth_error', 'Failed to send OTP.');
        }

        redirect('verify_otp.php');
    }

    /**
     * Render and process the email verification page.
     */
    public function verifyOtp(): void {
        $this->requireGuest();

        $email = $_SESSION['pending_email'] ?? '';
        if ($email === '') {
            redirect('register.php');
        }

        if (isset($_GET['resend'])) {
            $this->resendOtp();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $otp = trim($_POST['otp'] ?? '');
            $check = $this->userModel->canVerifyOtp($email, $otp);

            if (!$check['ok']) {
                flash_set('auth_error', $check['message']);
                redirect('verify_otp.php');
            }

            $this->userModel->markVerified($email);
            $_SESSION['setup_email'] = $email;
            unset($_SESSION['pending_email']);
            flash_set('auth_success', 'Email verified. Complete your profile setup next.');
            redirect('setup_account.php');
        }

        $this->renderAuth('auth/verify_otp', [
            'pageTitle' => 'Verify OTP',
            'heroTag' => 'Email Verification',
            'heroTitle' => 'Check your inbox',
            'heroDescription' => 'We sent a six-digit OTP to your email address.',
            'formTitle' => 'Verify OTP',
            'currentEmail' => $email,
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success'),
            'showRecaptcha' => false
        ]);
    }

    /**
     * Render and process the profile setup page after email verification.
     */
    public function setupAccount(): void {
        $this->requireGuest();

        $email = $_SESSION['setup_email'] ?? '';
        if ($email === '') {
            redirect('login.php');
        }

        $user = $this->userModel->findByEmail($email);
        if (!$user) {
            redirect('register.php');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $formData = [
                'first_name' => trim($_POST['first_name'] ?? ''),
                'middle_initial' => trim($_POST['middle_initial'] ?? ''),
                'last_name' => trim($_POST['last_name'] ?? ''),
                'suffix' => trim($_POST['suffix'] ?? ''),
                'username' => trim($_POST['username'] ?? ''),
                'student_id' => trim($_POST['student_id'] ?? ''),
                'year_level' => trim($_POST['year_level'] ?? ''),
                'section' => trim($_POST['section'] ?? '')
            ];

            if (
                $formData['first_name'] === '' ||
                $formData['last_name'] === '' ||
                $formData['username'] === '' ||
                $formData['student_id'] === '' ||
                $formData['year_level'] === '' ||
                $formData['section'] === ''
            ) {
                flash_set('auth_error', 'Please complete all required profile fields.');
                $_SESSION['setup_form'] = $formData;
                redirect('setup_account.php');
            }

            if ($this->userModel->profileIdentityExists($formData['username'], $formData['student_id'])) {
                flash_set('auth_error', 'Username or Student ID already exists.');
                $_SESSION['setup_form'] = $formData;
                redirect('setup_account.php');
            }

            if (!$this->userModel->completeProfile($email, $formData)) {
                flash_set('auth_error', 'Failed to save your account setup.');
                $_SESSION['setup_form'] = $formData;
                redirect('setup_account.php');
            }

            unset($_SESSION['setup_form']);
            $_SESSION['email'] = $email;
            $_SESSION['role'] = $user['role'];
            unset($_SESSION['setup_email']);

            flash_set('auth_success', 'Account setup completed. Welcome to the dashboard.');
            redirect('index.php?url=home');
        }

        $formData = $_SESSION['setup_form'] ?? [];
        unset($_SESSION['setup_form']);

        $this->renderAuth('auth/setup_account', [
            'pageTitle' => 'Setup Account',
            'heroTag' => 'Account Setup',
            'heroTitle' => 'Complete your profile',
            'heroDescription' => 'Finish the last step so your student dashboard can personalize itself.',
            'formTitle' => 'Student profile',
            'currentEmail' => $email,
            'formData' => $formData,
            'messageError' => flash_get('auth_error'),
            'messageSuccess' => flash_get('auth_success'),
            'showRecaptcha' => false
        ]);
    }

    /**
     * End the session and return to the login page.
     */
    public function logout(): void {
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'],
                (bool) $params['secure'],
                (bool) $params['httponly']
            );
        }

        session_destroy();
        redirect('login.php');
    }
}
