    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="js/script.js"></script>
<?php if (!empty($extraJs) && is_array($extraJs)): ?>
<?php foreach ($extraJs as $jsFile): ?>
    <script src="<?php echo e($jsFile); ?>"></script>
<?php endforeach; ?>
<?php endif; ?>
</div>
</body>
</html>
