<?php
/**
 * Admin dashboard view.
 * Admin is intentionally not listed in the user table to avoid accidental edits.
 */
?>
<div class="main-content home-page">
    <div class="dashboard-container">
        <section class="glass-hero">
            <div class="hero-text">
                <span class="welcome-tag">Admin Dashboard</span>
                <h1>Welcome, Admin!</h1>
                <p>Manage student accounts from one place.</p>
            </div>

            <div class="floating-cube">
                <i class="bi bi-shield-lock-fill"></i>
            </div>
        </section>

        <?php if (!empty($adminError)): ?>
            <div class="error-box"><?php echo e($adminError); ?></div>
        <?php endif; ?>

        <?php if (!empty($adminSuccess)): ?>
            <div class="success-box"><?php echo e($adminSuccess); ?></div>
        <?php endif; ?>

        <section class="stats-grid">
            <div class="glass-card">
                <i class="bi bi-people-fill"></i>
                <h3>Students</h3>
                <div class="stat-number"><?php echo e((string) $stats['students']); ?></div>
            </div>

            <div class="glass-card">
                <i class="bi bi-clock-history"></i>
                <h3>Pending</h3>
                <div class="stat-number"><?php echo e((string) $stats['pending']); ?></div>
            </div>

            <div class="glass-card">
                <i class="bi bi-slash-circle-fill"></i>
                <h3>Banned</h3>
                <div class="stat-number"><?php echo e((string) $stats['banned']); ?></div>
            </div>
        </section>

        <section class="profile-section single-form-block">
            <h3>Student Management</h3>

            <?php if (empty($users)): ?>
                <p>No students found.</p>
            <?php else: ?>
                <div style="overflow-x:auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $userRow): ?>
                                <tr>
                                    <td><?php echo e($userRow['email']); ?></td>
                                    <td><?php echo e($userRow['username'] ?: 'N/A'); ?></td>
                                    <td><?php echo e($userRow['status'] === 'verified' ? 'Active' : ucfirst($userRow['status'])); ?></td>
                                    <td><?php echo e(date('Y-m-d', strtotime($userRow['created_at']))); ?></td>
                                    <td>
                                        <div class="admin-action-row">
                                            <a href="index.php?url=admin_edit_user&id=<?php echo (int) $userRow['id']; ?>" class="edit-btn">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </a>

                                            <form method="POST" onsubmit="return confirm('Delete this user?');">
                                                <input type="hidden" name="user_id" value="<?php echo (int) $userRow['id']; ?>">
                                                <button type="submit" name="delete_user" class="edit-btn danger-btn" style="border:none; cursor:pointer;">
                                                    <i class="bi bi-trash-fill"></i> Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    </div>
</div>
