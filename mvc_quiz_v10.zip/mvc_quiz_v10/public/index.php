<?php
/**
 * Front controller for authenticated pages.
 * Routes requests to the correct controller based on the url parameter.
 */
session_start();

require_once "../App/Controllers/DashboardController.php";
require_once "../App/Controllers/ProfileController.php";
require_once "../App/Controllers/PasswordController.php";
require_once "../App/Controllers/AdminController.php";
require_once "../App/Models/User.php";

$userModel = new User();

if (empty($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$currentUser = $userModel->findByEmail($_SESSION['email']);

if (!$currentUser) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

if (($currentUser['status'] ?? '') !== 'verified') {
    $_SESSION['pending_email'] = $currentUser['email'];
    header("Location: verify_otp.php");
    exit();
}

if (empty($currentUser['profile_completed'])) {
    $_SESSION['setup_email'] = $currentUser['email'];
    header("Location: setup_account.php");
    exit();
}

$page = $_GET['url'] ?? 'home';

if (($currentUser['role'] ?? '') === 'admin') {
    $allowedAdminPages = ['admin_dashboard', 'admin_edit_user'];
    if (!in_array($page, $allowedAdminPages, true)) {
        $page = 'admin_dashboard';
    }
}

switch ($page) {
    case 'admin_dashboard':
        (new AdminController())->dashboard();
        break;

    case 'admin_edit_user':
        (new AdminController())->editUser();
        break;

    case 'profile':
        (new ProfileController())->show();
        break;

    case 'edit_profile':
        (new ProfileController())->edit();
        break;

    case 'change_password':
        (new PasswordController())->changePassword();
        break;

    case 'verify_change_password_otp':
        (new PasswordController())->verifyChangePasswordOtp();
        break;

    case 'set_new_password':
        (new PasswordController())->setNewPassword();
        break;

    case 'home':
    default:
        (new DashboardController())->show('home');
        break;
}
