/**
 * Sidebar interactions used by the authenticated application layout.
 * Keeps sidebar behavior and panel toggles in one place.
 */

if (typeof window.jQuery !== 'undefined') {
  $(document).ready(function () {
    $('.side-bar').addClass('no-slide');

    const state = localStorage.getItem('sidebar');
    if (state === 'open') {
      $('.side-bar').addClass('active');
      $('.menu-btn').addClass('hidden');
    }

    setTimeout(function () {
      $('.side-bar').removeClass('no-slide');
    }, 10);

    $('.menu-btn').click(function () {
      $('.side-bar').addClass('active');
      $('.menu-btn').addClass('hidden');
      localStorage.setItem('sidebar', 'open');
    });

    $('.close-btn').click(function () {
      $('.side-bar').removeClass('active');
      $('.menu-btn').removeClass('hidden');
      localStorage.setItem('sidebar', 'closed');
    });

    $('.sub-btn').click(function (event) {
      event.preventDefault();
      $(this).next('.sub-menu').slideToggle();
    });
  });
}

document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.password-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const targetId = btn.getAttribute('data-target');
      const input = document.getElementById(targetId);
      if (!input) return;

      const icon = btn.querySelector('i');

      if (input.type === 'password') {
        input.type = 'text';
        if (icon) {
          icon.classList.remove('bi-eye-fill');
          icon.classList.add('bi-eye-slash-fill');
        }
      } else {
        input.type = 'password';
        if (icon) {
          icon.classList.remove('bi-eye-slash-fill');
          icon.classList.add('bi-eye-fill');
        }
      }
    });
  });
});
